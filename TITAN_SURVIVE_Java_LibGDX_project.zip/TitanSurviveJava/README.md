# TITAN-SURVIVE — Java / libGDX

Projeto Android nativo em Java, com renderer 2D libGDX. Esta versão não é HTML/JavaScript.

## O que está nesta base
- Projeto Android (`android/`) e lógica de jogo Java (`core/`).
- Orientação `sensorLandscape`; a tela pode girar entre paisagem esquerda/direita.
- HUD e controles touch calculados novamente em `resize()`, ancorados nos cantos da tela.
- Câmera horizontal com follow suave do Mech.
- Fundo em três biomas com parallax: floresta das ruínas, floresta contaminada e zona de infestação.
- Mech pesado lateral em spritesheet de 8 frames.
- Inimigos, auto-aim/auto-fire, ciclo dia/noite, hordas, chefes, XP, upgrades, viajantes, drone e mísseis em implementação inicial.

## Requisitos
- Android Studio atualizado.
- JDK 17 para executar o Gradle/Android Gradle Plugin 8.13.
- Android SDK Platform 36.
- Gradle 8.13 (o Android Studio pode sincronizar a versão compatível).

A documentação oficial do libGDX atualmente indica a versão estável 1.14.2 e recomenda Android Studio para projetos Android/mobile.

## Abrir e compilar
1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `TitanSurviveJava` (onde está `settings.gradle`).
3. Aguarde a sincronização do Gradle e a instalação das dependências.
4. Conecte um Android com depuração USB ativada ou use um emulador em modo paisagem.
5. Use **Run** para instalar no dispositivo.
6. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Controles
- Desktop: A/D ou setas, Espaço para saltar, Shift para Jet-Dash, E/F para loja.
- Android: joystick à esquerda; Salto, Dash, Tiro e Loja à direita.
- O disparo principal e o drone são automáticos quando há inimigos no alcance.

## Observações honestas
- Este pacote contém o projeto-fonte Android/Java e assets.
- Não inclui APK compilado: a compilação Android exige o Android SDK e Gradle instalados no ambiente de build.
- A arte de fundo e os sprites foram criados como assets originais do projeto; podem ser refinados/exportados em Aseprite nas próximas iterações.
