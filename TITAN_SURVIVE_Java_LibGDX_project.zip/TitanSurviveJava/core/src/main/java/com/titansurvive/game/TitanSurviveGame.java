package com.titansurvive.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.Random;

/**
 * TITAN-SURVIVE - Native Java / libGDX implementation.
 * Android landscape first; camera and touch HUD are recalculated on every resize.
 */
public class TitanSurviveGame extends ApplicationAdapter {
    private static final float BASE_W = 1280f, BASE_H = 720f;
    private static final float WORLD_W = 33280f;
    private static final float FLOOR = 145f;
    private static final float GRAVITY = 1450f;

    private SpriteBatch batch;
    private ShapeRenderer shapes;
    private BitmapFont font;
    private OrthographicCamera worldCamera, uiCamera;
    private ExtendViewport worldViewport;
    private ScreenViewport uiViewport;

    private Texture forestDay, forestToxic, forestZone, groundTexture;
    private Texture mechSheet;
    private TextureRegion[] mechFrames;
    private Texture walkerTex, jumperTex, flyerTex, spitterTex, bossTex;

    private final Random random = new Random();
    private final Array<Enemy> enemies = new Array<>();
    private final Array<Projectile> projectiles = new Array<>();
    private final Array<Particle> particles = new Array<>();
    private final Array<Coin> coins = new Array<>();
    private final Array<Platform> platforms = new Array<>();
    private final Array<Float> merchants = new Array<>();

    private final Player player = new Player();
    private float cameraX;
    private float dayClock = 30f;
    private int day = 1, coins = 0, kills = 0, level = 1, xp = 0, xpNeed = 30;
    private int spawned = 0, nightQuota = 0, bossSpawnedDay = -1;
    private boolean night = false, gameOver = false;
    private float spawnClock = .6f, toastClock = 0f;
    private String toast = "TITAN UNIT ONLINE";
    private String sector = "FLORESTA DAS RUÍNAS";

    private boolean left, right, jumpHeld, fireHeld;
    private int joystickPointer = -1;
    private float joystickCenterX, joystickCenterY, joystickX;
    private boolean upgradeOpen, shopOpen;
    private String[] upgradeOptions = new String[3];
    private String[] shopOptions = new String[3];

    private float uiW, uiH;
    private float stickX, stickY, stickR, buttonR;
    private float jumpX, jumpY, dashX, dashY, fireX, fireY, shopX, shopY;

    private static final String[] WEAPONS = {
            "M-01 CANHÃO CINÉTICO", "M-02 ESCOPETA DE ESTILHAÇO",
            "M-03 FEIXE DE PLASMA", "M-04 LANÇA-ÍONS",
            "M-05 METRALHADORA VULCAN", "M-06 CANHÃO DE CERCO",
            "M-07 DISRUPTOR SÔNICO", "M-08 ARCO ELÉTRICO",
            "M-09 LANÇA-ÁCIDO", "M-10 RIFLE GAUSS",
            "M-11 LÂMINA DE FÓTONS", "M-12 CANHÃO CRIOGÊNICO",
            "M-13 MORTEIRO MAGNÉTICO", "M-14 RASTRO INCENDIÁRIO",
            "M-15 FEIXE PRISMÁTICO", "M-16 ANIQUILADOR",
            "M-17 CANHÃO DE SINGULARIDADE", "M-18 TEMPESTADE IÔNICA",
            "M-19 DEVASTADOR ÔMEGA", "M-20 NÚCLEO SOLAR", "M-21 PROTOCOLO TITÃ"
    };

    @Override public void create() {
        batch = new SpriteBatch();
        shapes = new ShapeRenderer();
        font = new BitmapFont();
        font.getData().setScale(1.05f);
        worldCamera = new OrthographicCamera();
        uiCamera = new OrthographicCamera();
        worldViewport = new ExtendViewport(BASE_W, BASE_H, worldCamera);
        uiViewport = new ScreenViewport(uiCamera);

        forestDay = texture("forest_day.jpg", false);
        forestToxic = texture("forest_toxic.jpg", false);
        forestZone = texture("forest_zone.jpg", false);
        groundTexture = texture("ground.png", true);
        mechSheet = texture("mech_walk.png", true);
        mechFrames = TextureRegion.split(mechSheet, 128, 128)[0];
        walkerTex = texture("walker.png", true);
        jumperTex = texture("jumper.png", true);
        flyerTex = texture("flyer.png", true);
        spitterTex = texture("spitter.png", true);
        bossTex = texture("boss.png", true);

        for (int i = 0; i < 8; i++) merchants.add(700f + i * ((WORLD_W - 1500f) / 7f));
        for (int i = 0; i < 42; i++) {
            float x = 430 + i * 720f;
            platforms.add(new Platform(x, FLOOR + 110 + random.nextInt(65),
                    130 + random.nextInt(110), 18));
        }

        player.x = 180;
        player.y = FLOOR;
        Gdx.input.setInputProcessor(new Controls());
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
    }

    private Texture texture(String name, boolean nearest) {
        Texture t = new Texture(Gdx.files.internal(name));
        t.setFilter(nearest ? Texture.TextureFilter.Nearest : Texture.TextureFilter.Linear,
                    nearest ? Texture.TextureFilter.Nearest : Texture.TextureFilter.Linear);
        return t;
    }

    @Override public void resize(int width, int height) {
        worldViewport.update(width, height, true);
        uiViewport.update(width, height, true);
        uiW = uiViewport.getWorldWidth();
        uiH = uiViewport.getWorldHeight();
        worldCamera.position.set(player.x + 210f, BASE_H / 2f, 0);
        worldCamera.update();
        layoutControls();
    }

    private void layoutControls() {
        stickR = MathUtils.clamp(uiH * .105f, 42f, 64f);
        buttonR = MathUtils.clamp(uiH * .085f, 34f, 52f);
        stickX = Math.max(stickR + 18, uiW * .105f);
        stickY = stickR + 22;
        jumpX = uiW - buttonR - 22; jumpY = buttonR + 22;
        dashX = uiW - buttonR - 22; dashY = jumpY + buttonR * 2.35f;
        fireX = uiW - buttonR * 3.15f; fireY = jumpY;
        shopX = uiW - buttonR * 3.15f; shopY = dashY;
    }

    @Override public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), .033f);
        update(dt);
        Gdx.gl.glClearColor(.035f, .055f, .07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        drawWorld();
    }

    private void update(float dt) {
        if (gameOver || upgradeOpen || shopOpen) return;

        player.animTime += dt;
        player.invuln = Math.max(0, player.invuln - dt);
        player.dashTime = Math.max(0, player.dashTime - dt);
        player.dashCooldown = Math.max(0, player.dashCooldown - dt);
        player.muzzleTime = Math.max(0, player.muzzleTime - dt);
        player.recoil = Math.max(0, player.recoil - dt * 8f);
        player.hurtFlash = Math.max(0, player.hurtFlash - dt);
        player.missileCooldown -= dt;
        player.droneCooldown -= dt;
        player.repairTimer += dt;

        float move = (right ? 1 : 0) - (left ? 1 : 0) + joystickX;
        move = MathUtils.clamp(move, -1, 1);
        if (player.dashTime > 0) player.vx = player.face * 760f;
        else if (Math.abs(move) > .08f) {
            player.face = move > 0 ? 1 : -1;
            player.vx = move * player.speed;
        } else player.vx = MathUtils.lerp(player.vx, 0, Math.min(1, dt * 9f));

        player.x = MathUtils.clamp(player.x + player.vx * dt, 45, WORLD_W - 75);
        if (jumpHeld && player.grounded) {
            player.vy = 625f;
            player.grounded = false;
            spawnDust(player.x, player.y + 3, 7);
        }
        player.vy -= GRAVITY * dt;
        player.y += player.vy * dt;
        if (player.y <= FLOOR) {
            if (!player.grounded && player.vy < -300) spawnDust(player.x, FLOOR + 3, 12);
            player.y = FLOOR;
            player.vy = 0;
            player.grounded = true;
        }

        player.stepTimer -= dt;
        if (Math.abs(player.vx) > 70 && player.grounded && player.stepTimer <= 0) {
            spawnDust(player.x - player.face * 12, FLOOR + 3, 3);
            player.stepTimer = .24f;
        }

        player.fireTimer -= dt;
        Enemy target = nearestEnemy(620);
        if (target != null && player.fireTimer <= 0) fireAt(target);
        updateSupport(dt, target);
        updateCycle(dt);
        updateEnemies(dt);
        updateProjectiles(dt);
        updateParticles(dt);
        collectCoins();

        cameraX = MathUtils.lerp(cameraX,
                MathUtils.clamp(player.x - worldViewport.getWorldWidth() * .40f,
                        0, WORLD_W - worldViewport.getWorldWidth()),
                Math.min(1, dt * 5.5f));
        worldCamera.position.set(cameraX + worldViewport.getWorldWidth() * .5f,
                BASE_H * .5f, 0);
        worldCamera.update();

        if (toastClock > 0) toastClock -= dt;
        if (player.repair > 0 && player.repairTimer >= 1f) {
            player.hp = Math.min(player.maxHp, player.hp + player.repair * 2f);
            player.repairTimer = 0;
        }
        if (player.hp <= 0) {
            player.hp = 0;
            gameOver = true;
            toast = "TITAN DESTRUÍDO · TOQUE PARA REINICIAR";
            toastClock = 999;
        }
    }

    private void updateCycle(float dt) {
        dayClock -= dt;
        if (dayClock <= 0) {
            if (!night) {
                night = true;
                dayClock = 30;
                spawned = 0;
                nightQuota = Math.min(500, Math.max(8,
                        (int)Math.ceil(8 * Math.pow(1.34, day - 1))));
                spawnClock = .3f;
                showToast("NOITE · HORDA DETECTADA");
            } else if (spawned >= nightQuota && enemies.size == 0) {
                day++;
                night = false;
                dayClock = 30;
                updateSector();
                showToast("DIA " + day + " · " + sector);
            } else {
                dayClock = 4f; // short extension while remaining enemies are cleared
            }
        }
        if (night) {
            spawnClock -= dt;
            if (spawned < nightQuota && spawnClock <= 0) {
                spawnEnemy();
                spawned++;
                spawnClock = Math.max(.28f, 1.25f - day * .025f);
            }
            if (day % 5 == 0 && bossSpawnedDay != day) {
                spawnBoss(day % 10 == 0);
                bossSpawnedDay = day;
            }
        }
    }

    private void updateSector() {
        if (day <= 3) sector = "FLORESTA DAS RUÍNAS";
        else if (day <= 7) sector = "FLORESTA CONTAMINADA";
        else sector = "ZONA DE INFESTAÇÃO";
    }

    private void spawnEnemy() {
        float x = player.x + (random.nextBoolean() ? 1 : -1) * (520 + random.nextFloat() * 250);
        x = MathUtils.clamp(x, 60, WORLD_W - 60);
        int kind;
        if (day >= 4 && random.nextFloat() < .22f) kind = Enemy.SPITTER;
        else if (day >= 3 && random.nextFloat() < .22f) kind = Enemy.FLYER;
        else if (day >= 2 && random.nextFloat() < .30f) kind = Enemy.JUMPER;
        else kind = Enemy.WALKER;
        float baseHp = kind == Enemy.SPITTER ? 78 : kind == Enemy.FLYER ? 54 :
                kind == Enemy.JUMPER ? 62 : 48;
        Enemy e = new Enemy(kind, x, FLOOR, baseHp * (float)Math.pow(1.16, day-1),
                (kind == Enemy.JUMPER ? 106 : kind == Enemy.FLYER ? 86 : 58) * (1 + day * .035f),
                8 + day * 1.2f);
        enemies.add(e);
    }

    private void spawnBoss(boolean main) {
        float x = MathUtils.clamp(player.x + 640, 100, WORLD_W - 120);
        Enemy e = new Enemy(Enemy.BOSS, x, FLOOR,
                (main ? 1800 : 620) * (float)Math.pow(1.14, day-1),
                main ? 48 : 58, main ? 34 : 22);
        e.mainBoss = main;
        e.w = main ? 150 : 105;
        e.h = main ? 155 : 110;
        enemies.add(e);
        showToast(main ? "COLOSSO MECÂNICO-ORGÂNICO" : "ELITE DE SUPERFÍCIE");
    }

    private Enemy nearestEnemy(float range) {
        Enemy best = null;
        float bestD = range;
        for (Enemy e : enemies) {
            float d = Vector2.dst(player.x, player.y + 70, e.x, e.y + e.h * .45f);
            if (d < bestD) { bestD = d; best = e; }
        }
        return best;
    }

    private void fireAt(Enemy e) {
        float sx = player.x + player.face * 55f;
        float sy = player.y + 82f;
        float tx = e.x, ty = e.y + e.h * .52f;
        float dx = tx - sx, dy = ty - sy;
        float len = Math.max(1, (float)Math.sqrt(dx*dx + dy*dy));
        player.face = dx >= 0 ? 1 : -1;
        float speed = 690f;
        boolean critical = random.nextFloat() < player.crit;
        projectiles.add(new Projectile(sx, sy, dx/len*speed, dy/len*speed,
                player.damage * (critical ? 2 : 1), false, false, critical));
        player.fireTimer = player.fireRate;
        player.muzzleTime = .13f;
        player.recoil = 1.8f;
        spawnMuzzle(sx, sy);
    }

    private void spawnMuzzle(float x, float y) {
        for (int i=0;i<8;i++) {
            float a = random.nextFloat() * MathUtils.PI2;
            float speed = 55 + random.nextFloat()*190;
            particles.add(new Particle(x,y,MathUtils.cos(a)*speed,MathUtils.sin(a)*speed,
                    .20f + random.nextFloat()*.15f, new Color(1f,.65f,.20f,1), 2+random.nextFloat()*4));
        }
        particles.add(new Particle(x,y,0,0,.10f,Color.WHITE,18));
    }

    private void updateSupport(float dt, Enemy target) {
        if (player.drone > 0 && target != null) {
            player.droneCooldown -= dt;
            if (player.droneCooldown <= 0) {
                float dx=target.x-player.x,dy=target.y-player.y;
                float len=Math.max(1,(float)Math.sqrt(dx*dx+dy*dy));
                projectiles.add(new Projectile(player.x-34,player.y+95,dx/len*540,dy/len*540,
                        player.damage*.42f,false,true,false));
                player.droneCooldown = player.drone >= 3 ? .38f : .82f;
            }
            if(player.drone>=2){
                player.empTimer-=dt;
                if(player.empTimer<=0){
                    for(Enemy e:enemies)if(Vector2.dst(e.x,e.y,player.x,player.y)<185)e.stun=1.4f;
                    player.empTimer=10f;
                }
            }
        }
        if(player.missiles>0 && target!=null){
            player.missileCooldown-=dt;
            if(player.missileCooldown<=0){
                float dx=target.x-player.x,dy=target.y-player.y;
                float len=Math.max(1,(float)Math.sqrt(dx*dx+dy*dy));
                projectiles.add(new Projectile(player.x,player.y+100,dx/len*310,dy/len*310,
                        player.damage*(player.missiles==1?1.3f:2.1f),false,false,false,true));
                player.missileCooldown=player.missiles>=3?2.8f:5f;
            }
        }
        if(player.shield>0){
            for(Enemy e:enemies)if(Vector2.dst(e.x,e.y,player.x,player.y)<76){
                e.x += Math.signum(e.x-player.x)*dt*180*player.shield;
                e.hp -= dt*5*player.shield;
            }
        }
    }

    private void updateEnemies(float dt) {
        for (int i=enemies.size-1;i>=0;i--) {
            Enemy e=enemies.get(i);
            if(e.stun>0){e.stun-=dt;continue;}
            float dx=player.x-e.x;
            if(e.kind==Enemy.FLYER){
                e.x += Math.signum(dx)*e.speed*.25f*dt;
                e.y = FLOOR + 135 + (float)Math.sin(e.clock*3)*24;
            } else if(e.kind==Enemy.SPITTER){
                e.x += Math.signum(dx)*e.speed*.3f*dt;
                e.attackTimer -= dt;
                if(e.attackTimer<=0){
                    float dir=Math.signum(player.x-e.x);
                    projectiles.add(new Projectile(e.x,e.y+60,dir*210,-70,e.damage,true,false,false,true));
                    e.attackTimer=2.3f;
                }
            } else {
                e.x += Math.signum(dx)*e.speed*dt;
                if(e.kind==Enemy.JUMPER){
                    e.jumpTimer -= dt;
                    if(e.jumpTimer<=0 && e.y<=FLOOR+1){e.vy=390;e.jumpTimer=1.15f;}
                }
                if(e.kind==Enemy.BOSS){
                    e.attackTimer -= dt;
                    if(e.attackTimer<=0){
                        for(int n=-2;n<=2;n++)projectiles.add(new Projectile(e.x,e.y+55,n*120,-220,e.damage,true,false,false,true));
                        e.attackTimer=e.mainBoss?1.15f:1.7f;
                    }
                }
            }
            if(e.vy!=0){e.vy-=900*dt;e.y+=e.vy*dt;if(e.y<FLOOR){e.y=FLOOR;e.vy=0;}}
            e.clock += dt;
            e.contactTimer -= dt;
            if(Math.abs(e.x-player.x)<(e.w+player.w)*.5f && Math.abs(e.y-player.y)<70 && e.contactTimer<=0){
                damagePlayer(e.damage);e.contactTimer=.9f;
            }
            if(e.hp<=0)killEnemy(e);
        }
    }

    private void updateProjectiles(float dt) {
        for(int i=projectiles.size-1;i>=0;i--){
            Projectile p=projectiles.get(i);
            p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;
            if(p.rocket){
                Enemy target=nearestEnemy(800);
                if(target!=null){float dx=target.x-p.x,dy=target.y+target.h/2-p.y;float len=Math.max(1,(float)Math.sqrt(dx*dx+dy*dy));p.vx=MathUtils.lerp(p.vx,dx/len*340,dt*2);p.vy=MathUtils.lerp(p.vy,dy/len*340,dt*2);}
            }
            if(!p.enemy){
                for(int j=enemies.size-1;j>=0;j--){
                    Enemy e=enemies.get(j);
                    if(Math.abs(p.x-e.x)<e.w*.48f && Math.abs(p.y-(e.y+e.h*.45f))<e.h*.48f){
                        e.hp-=p.damage;
                        if(p.rocket){for(Enemy other:enemies)if(Vector2.dst(other.x,other.y,p.x,p.y)<115)other.hp-=p.damage*.55f;explosion(p.x,p.y);}
                        else spawnImpact(p.x,p.y,p.critical);
                        if(e.hp<=0)killEnemy(e);
                        p.life=0;break;
                    }
                }
            }else if(Math.abs(p.x-player.x)<34 && Math.abs(p.y-(player.y+70))<48){
                damagePlayer(p.damage);p.life=0;if(p.rocket)explosion(p.x,p.y);
            }
            if(p.life<=0 || p.x<cameraX()-180 || p.x>cameraX()+worldViewport.getWorldWidth()+300)projectiles.removeIndex(i);
        }
    }

    private void killEnemy(Enemy e) {
        if(!enemies.removeValue(e,true))return;
        kills++;coins += e.kind==Enemy.BOSS?100: e.kind==Enemy.WALKER?3:8;
        coins += e.kind==Enemy.BOSS?100:0;
        addXP(e.kind==Enemy.BOSS?65:e.kind==Enemy.WALKER?7:12);
        spawnCoin(e.x,e.y+25);
        explosion(e.x,e.y+e.h*.4f);
        if(e.kind==Enemy.BOSS){player.hp=player.maxHp;showToast("CHEFE DERROTADO · BLINDAGEM RESTAURADA");}
    }

    private void addXP(int value) {
        xp+=value;
        while(xp>=xpNeed){xp-=xpNeed;level++;xpNeed=(int)(xpNeed*1.28f+8);openUpgrade();}
    }

    private void openUpgrade() {
        String[] normal={"DANO +22%","CADÊNCIA +18%","BLINDAGEM +35","CRÍTICO +8%","DRONE DE APOIO","POD DE MÍSSEIS","ESCUDO CINÉTICO","KIT DE REPARO"};
        String[] mythic={"TEMPESTADE IÔNICA","ANIQUILADOR ÔMEGA","NÚCLEO SOLAR"};
        String[] pool=(level==10||level==20||level==30||level==40)?mythic:normal;
        for(int i=0;i<3;i++)upgradeOptions[i]=pool[random.nextInt(pool.length)];
        upgradeOpen=true;
    }

    private void chooseUpgrade(int index) {
        String choice=upgradeOptions[index];
        if(choice.startsWith("DANO"))player.damage*=1.22f;
        else if(choice.startsWith("CADÊNCIA"))player.fireRate=Math.max(.08f,player.fireRate*.82f);
        else if(choice.startsWith("BLINDAGEM")){player.maxHp+=35;player.hp=Math.min(player.maxHp,player.hp+35);}
        else if(choice.startsWith("CRÍTICO"))player.crit=Math.min(.55f,player.crit+.08f);
        else if(choice.equals("DRONE DE APOIO"))player.drone=Math.min(3,player.drone+1);
        else if(choice.equals("POD DE MÍSSEIS"))player.missiles=Math.min(3,player.missiles+1);
        else if(choice.equals("ESCUDO CINÉTICO"))player.shield=Math.min(3,player.shield+1);
        else if(choice.equals("KIT DE REPARO"))player.repair=Math.min(3,player.repair+1);
        else if(choice.equals("TEMPESTADE IÔNICA")){player.weapon=17;player.damage*=1.45f;}
        else if(choice.equals("ANIQUILADOR ÔMEGA")){player.weapon=18;player.damage*=1.6f;}
        else if(choice.equals("NÚCLEO SOLAR")){player.weapon=19;player.damage*=1.4f;}
        upgradeOpen=false;
    }

    private void damagePlayer(float damage) {
        if(player.invuln>0)return;
        player.hp-=damage;player.invuln=.65f;player.hurtFlash=.18f;
        for(int i=0;i<12;i++)particles.add(new Particle(player.x,player.y+55,
                random.nextFloat()*250-125,random.nextFloat()*190-40,.32f,
                new Color(1,.28f,.22f,1),3+random.nextFloat()*3));
    }

    private void spawnImpact(float x,float y,boolean critical) {
        Color c=critical?new Color(1,.92f,.54f,1):new Color(1,.63f,.24f,1);
        for(int i=0;i<7;i++){float a=random.nextFloat()*MathUtils.PI2,s=40+random.nextFloat()*190;
            particles.add(new Particle(x,y,MathUtils.cos(a)*s,MathUtils.sin(a)*s,.25f,c,2+random.nextFloat()*3));}
    }
    private void explosion(float x,float y) {
        for(int i=0;i<28;i++){float a=random.nextFloat()*MathUtils.PI2,s=50+random.nextFloat()*260;
            particles.add(new Particle(x,y,MathUtils.cos(a)*s,MathUtils.sin(a)*s,.55f,
                    random.nextBoolean()?new Color(1,.54f,.16f,1):new Color(1,.84f,.46f,1),3+random.nextFloat()*6));}
    }
    private void spawnDust(float x,float y,int count) {
        for(int i=0;i<count;i++)particles.add(new Particle(x+random.nextFloat()*16-8,y,
                random.nextFloat()*70-35,random.nextFloat()*55,.35f,
                new Color(.68f,.65f,.47f,.75f),2+random.nextFloat()*4));
    }
    private void spawnCoin(float x,float y){coins += 0; /* pickup is visual, coins are awarded on kill */ coinsPickupVisual.add(new Coin(x,y));}
    private final Array<Coin> coinsPickupVisual=new Array<>();
    private void collectCoins() {
        for(int i=coinsPickupVisual.size-1;i>=0;i--){
            Coin c=coinsPickupVisual.get(i);
            float dx=player.x-c.x,dy=player.y+40-c.y;
            c.x+=dx*Math.min(1,Gdx.graphics.getDeltaTime()*2.5f);
            c.y+=dy*Math.min(1,Gdx.graphics.getDeltaTime()*2.5f);
            c.life-=Gdx.graphics.getDeltaTime();
            if(Math.abs(dx)<32&&Math.abs(dy)<45||c.life<=0)coinsPickupVisual.removeIndex(i);
        }
    }

    private void openShop() {
        boolean nearby=false;
        for(Float x:merchants)if(Math.abs(x-player.x)<150){nearby=true;break;}
        if(!nearby){showToast("APROXIME-SE DE UM VIAJANTE");return;}
        shopOptions=new String[]{"KIT MÉDICO · 35","MUNIÇÃO · 55","PEÇAS DE DRONE · 80"};
        shopOpen=true;
    }
    private void chooseShop(int i) {
        if(i==0&&coins>=35){coins-=35;player.hp=Math.min(player.maxHp,player.hp+65);}
        else if(i==1&&coins>=55){coins-=55;player.damage*=1.3f;}
        else if(i==2&&coins>=80){coins-=80;player.drone=Math.min(3,player.drone+1);}
        else showToast("MOEDAS INSUFICIENTES");
        shopOpen=false;
    }

    private void updateParticles(float dt) {
        for(int i=particles.size-1;i>=0;i--){Particle p=particles.get(i);p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy-=260*dt;p.life-=dt;if(p.life<=0)particles.removeIndex(i);}
    }
    private void showToast(String text){toast=text;toastClock=2.3f;}
    private float cameraX(){return cameraX;}

    private void drawWorld() {
        worldViewport.apply();
        batch.setProjectionMatrix(worldCamera.combined);
        float viewLeft=worldCamera.position.x-worldViewport.getWorldWidth()/2f;
        float viewRight=worldCamera.position.x+worldViewport.getWorldWidth()/2f;

        // Painterly background and ground.
        batch.begin();
        Texture bg = day<=3?forestDay:day<=7?forestToxic:forestZone;
        drawParallax(bg,.16f);
        for(float x=(float)Math.floor(viewLeft/groundTexture.getWidth())*groundTexture.getWidth();
            x<viewRight+groundTexture.getWidth();x+=groundTexture.getWidth()){
            batch.draw(groundTexture,x,0,groundTexture.getWidth(),FLOOR+25);
        }
        batch.end();

        // Midground geometry and support characters.
        shapes.setProjectionMatrix(worldCamera.combined);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        for(Platform p:platforms)if(p.x>viewLeft-180&&p.x<viewRight+180){
            shapes.setColor(.30f,.27f,.19f,1);shapes.rect(p.x,p.y,p.w,p.h);
            shapes.setColor(.55f,.61f,.31f,1);shapes.rect(p.x,p.y+p.h-6,p.w,6);
            shapes.setColor(.70f,.65f,.38f,1);shapes.rect(p.x+5,p.y+p.h-9,p.w-10,3);
        }
        for(Float x:merchants)if(Math.abs(x-player.x)<worldViewport.getWorldWidth()*.8f){
            shapes.setColor(.25f,.34f,.27f,1);shapes.rect(x-10,FLOOR+6,20,32);
            shapes.setColor(.72f,.65f,.50f,1);shapes.circle(x,FLOOR+45,10,10);
            shapes.setColor(.82f,.28f,.23f,1);shapes.rect(x-4,FLOOR+45,8,3);
        }
        for(Projectile p:projectiles){
            if(p.enemy)shapes.setColor(.68f,.88f,.35f,1);
            else if(p.rocket)shapes.setColor(1,.42f,.17f,1);
            else shapes.setColor(1,.80f,.35f,1);
            shapes.circle(p.x,p.y,p.rocket?8:4,12);
            shapes.setColor(1,.94f,.70f,.22f);shapes.circle(p.x,p.y,p.rocket?20:12,16);
        }
        for(Coin c:coinsPickupVisual){
            shapes.setColor(1f,.78f,.34f,1);shapes.circle(c.x,c.y,6,10);
            shapes.setColor(1f,.95f,.69f,.35f);shapes.circle(c.x,c.y,12,12);
        }
        shapes.end();

        // Characters and layered sprites.
        batch.begin();
        for(Enemy e:enemies)drawEnemy(e);
        int frame=0;
        if(Math.abs(player.vx)>35&&player.grounded)frame=(int)(player.animTime*10)%8;
        TextureRegion region=mechFrames[frame];
        boolean flip=player.face<0;
        if(region.isFlipX()!=flip)region.flip(true,false);
        batch.setColor(player.hurtFlash>0?new Color(1,.65f,.62f,1):Color.WHITE);
        batch.draw(region,player.x-64,player.y-7,128,128);
        batch.setColor(Color.WHITE);
        batch.end();

        // Additive / painterly VFX glow. No camera shake: stable tracking is intentional.
        shapes.setProjectionMatrix(worldCamera.combined);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        for(Enemy e:enemies)if(e.hp<e.maxHp){
            shapes.setColor(.10f,.08f,.08f,1);shapes.rect(e.x-e.w/2,e.y+e.h+9,e.w,5);
            shapes.setColor(.84f,.27f,.24f,1);shapes.rect(e.x-e.w/2,e.y+e.h+9,e.w*MathUtils.clamp(e.hp/e.maxHp,0,1),5);
        }
        if(player.drone>0){
            float x=player.x-48,y=player.y+128+(float)Math.sin(player.animTime*3)*8;
            shapes.setColor(.28f,.42f,.39f,1);shapes.rect(x-13,y-7,26,14);
            shapes.setColor(.77f,.83f,.70f,1);shapes.rect(x-8,y+7,16,5);
            shapes.setColor(.90f,.27f,.22f,1);shapes.circle(x,y,3,10);
        }
        for(Enemy e:enemies)if(e.hp<e.maxHp){
            shapes.setColor(.08f,.06f,.06f,.95f);
            shapes.rect(e.x-e.w/2f,e.y+e.h+8,e.w,5);
            shapes.setColor(.84f,.27f,.24f,1);
            shapes.rect(e.x-e.w/2f,e.y+e.h+8,e.w*MathUtils.clamp(e.hp/e.maxHp,0,1),5);
        }
        for(Particle p:particles){
            float alpha=MathUtils.clamp(p.life/p.maxLife,0,1);
            Color c=new Color(p.color);c.a=alpha;
            shapes.setColor(c);shapes.circle(p.x,p.y,p.size*alpha,8);
            if(p.size>5){c.a=alpha*.18f;shapes.setColor(c);shapes.circle(p.x,p.y,p.size*2.4f,12);}
        }
        if(player.muzzleTime>0){
            float alpha=player.muzzleTime/.13f;
            shapes.setColor(1f,.63f,.18f,alpha*.25f);
            shapes.circle(player.x+player.face*73,player.y+87,30*alpha,20);
            shapes.setColor(1f,.92f,.64f,alpha);
            shapes.circle(player.x+player.face*73,player.y+87,8*alpha,16);
        }
        if(night){
            shapes.setColor(.025f,.035f,.075f,.20f);
            shapes.rect(viewLeft,0,worldViewport.getWorldWidth(),worldViewport.getWorldHeight());
        }
        shapes.end();
        drawHUD();
    }

    private void drawEnemy(Enemy e) {
        Texture texture;
        if(e.kind==Enemy.WALKER) texture=walkerTex;
        else if(e.kind==Enemy.JUMPER) texture=jumperTex;
        else if(e.kind==Enemy.FLYER) texture=flyerTex;
        else if(e.kind==Enemy.SPITTER) texture=spitterTex;
        else texture=bossTex;
        batch.draw(texture,e.x-e.w/2f,e.y,e.w,e.h);
    }

    private void drawParallax(Texture tex,float parallax) {
        float viewWidth=worldViewport.getWorldWidth();
        float viewLeft=worldCamera.position.x-viewWidth/2f;
        float offset=-((worldCamera.position.x*parallax)%tex.getWidth());
        float x=worldCamera.position.x-viewWidth/2f+offset;
        float alpha=parallax<.2f?1f:.45f;
        batch.setColor(1,1,1,alpha);
        for(;x<viewLeft+viewWidth+tex.getWidth();x+=tex.getWidth())
            batch.draw(tex,x,0,tex.getWidth(),worldViewport.getWorldHeight());
        batch.setColor(Color.WHITE);
    }

    private void drawPlayer() {
        int frame=0;
        if(Math.abs(player.vx)>35&&player.grounded)frame=(int)(player.animTime*10)%8;
        TextureRegion region=mechFrames[frame];
        boolean flip=player.face<0;
        if(region.isFlipX()!=flip)region.flip(true,false);
        float height=128,width=128;
        batch.setColor(player.hurtFlash>0?new Color(1,.65f,.62f,1):Color.WHITE);
        batch.draw(region,player.x-width/2,player.y-7,width,height);
        batch.setColor(Color.WHITE);
    }

    private void drawDrone() {
        float x=player.x-48,y=player.y+128+(float)Math.sin(player.animTime*3)*8;
        shapes.setProjectionMatrix(worldCamera.combined);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(.28f,.42f,.39f,1);shapes.rect(x-13,y-7,26,14);
        shapes.setColor(.77f,.83f,.70f,1);shapes.rect(x-8,y+7,16,5);
        shapes.setColor(.90f,.27f,.22f,1);shapes.circle(x,y,3,10);
        shapes.end();
    }

    private void drawHUD() {
        uiViewport.apply();
        shapes.setProjectionMatrix(uiCamera.combined);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // Top-left status card and top-right day panel.
        shapes.setColor(.055f,.085f,.075f,.93f);shapes.rect(14,uiH-142,Math.min(390,uiW*.48f),128);
        shapes.setColor(.10f,.14f,.12f,.95f);shapes.rect(uiW-205,uiH-112,190,98);
        drawBar(30,uiH-70,Math.min(345,uiW*.42f),8,player.hp/player.maxHp,new Color(.88f,.30f,.25f,1));
        drawBar(30,uiH-106,Math.min(345,uiW*.42f),7,xp/(float)xpNeed,new Color(.35f,.78f,.69f,1));
        // Joystick and four action buttons are anchored against the live viewport dimensions.
        shapes.setColor(.10f,.18f,.19f,.78f);shapes.circle(stickX,stickY,stickR,32);
        shapes.setColor(.65f,.77f,.76f,.85f);shapes.circle(stickX+joystickX*stickR*.42f,stickY,stickR*.34f,28);
        button(jumpX,jumpY,buttonR,new Color(.91f,.68f,.34f,1));
        button(dashX,dashY,buttonR,new Color(.83f,.57f,.27f,1));
        button(fireX,fireY,buttonR,new Color(.37f,.70f,.69f,1));
        button(shopX,shopY,buttonR,new Color(.56f,.69f,.39f,1));
        shapes.end();

        batch.setProjectionMatrix(uiCamera.combined);batch.begin();
        font.setColor(new Color(.95f,.68f,.30f,1));font.draw(batch,"TITAN-SURVIVE",30,uiH-33);
        font.setColor(Color.WHITE);font.draw(batch,"BLINDAGEM  "+(int)player.hp+" / "+(int)player.maxHp,30,uiH-52);
        font.draw(batch,"XP  "+xp+" / "+xpNeed+"     DRONE "+player.drone+"  MISSEIS "+player.missiles,30,uiH-91);
        font.setColor(new Color(.9f,.9f,.82f,1));font.draw(batch,"DIA "+day,uiW-185,uiH-39);
        font.draw(batch,(night?"HORDA ":"EXPLORACAO ")+(int)dayClock+"s",uiW-185,uiH-62);
        font.setColor(new Color(1,.78f,.40f,1));font.draw(batch,"MOEDAS "+coins,uiW-185,uiH-86);
        font.setColor(Color.WHITE);font.draw(batch,WEAPONS[MathUtils.clamp(player.weapon,0,WEAPONS.length-1)],30,uiH-128);
        font.draw(batch,"SALTO",jumpX-22,jumpY+4);font.draw(batch,"DASH",dashX-19,dashY+4);
        font.draw(batch,"TIRO",fireX-17,fireY+4);font.draw(batch,"LOJA",shopX-17,shopY+4);
        if(toastClock>0){font.setColor(new Color(1,.84f,.49f,1));font.draw(batch,toast,uiW*.5f-100,uiH*.72f);}
        if(upgradeOpen||shopOpen||gameOver)drawModalText();
        batch.end();
        if(upgradeOpen||shopOpen||gameOver)drawModalPanels();
    }

    private void drawBar(float x,float y,float w,float h,float value,Color c) {
        shapes.setColor(.15f,.20f,.19f,1);shapes.rect(x,y,w,h);
        shapes.setColor(c);shapes.rect(x,y,w*MathUtils.clamp(value,0,1),h);
    }
    private void button(float x,float y,float r,Color c) {
        shapes.setColor(.02f,.04f,.04f,.6f);shapes.circle(x,y-3,r+3,32);
        shapes.setColor(c);shapes.circle(x,y,r,32);
        shapes.setColor(1,1,1,.72f);shapes.circle(x,y,r-4,32);
    }

    private void drawModalText() {
        if(upgradeOpen){font.setColor(new Color(1,.72f,.3f,1));font.draw(batch,"ESCOLHA UMA MELHORIA",uiW*.5f-115,uiH*.62f);}
        else if(shopOpen){font.setColor(new Color(1,.72f,.3f,1));font.draw(batch,"MERCADO DO VIAJANTE",uiW*.5f-105,uiH*.62f);}
        else {font.setColor(Color.WHITE);font.draw(batch,"TITAN DESTRUIDO · TOQUE PARA REINICIAR",uiW*.5f-155,uiH*.62f);}
    }

    private void drawModalPanels() {
        shapes.setProjectionMatrix(uiCamera.combined);shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(.035f,.055f,.05f,.96f);shapes.rect(uiW*.16f,uiH*.23f,uiW*.68f,uiH*.34f);
        shapes.setColor(.67f,.43f,.19f,1);shapes.rect(uiW*.16f,uiH*.23f,uiW*.68f,3);
        shapes.end();
        batch.setProjectionMatrix(uiCamera.combined);batch.begin();
        String[] opts=upgradeOpen?upgradeOptions:shopOpen?shopOptions:new String[]{"REINICIAR"};
        float cardW=uiW*.19f,gap=uiW*.025f,total=cardW*opts.length+gap*(opts.length-1);
        float start=(uiW-total)/2f;
        for(int i=0;i<opts.length;i++){
            float x=start+i*(cardW+gap);
            font.setColor(new Color(.95f,.9f,.75f,1));font.draw(batch,(i+1)+". "+opts[i],x,uiH*.42f,cardW,1,true);
        }
        batch.end();
    }

    private class Controls extends InputAdapter {
        @Override public boolean keyDown(int key) {
            if(key==Input.Keys.A||key==Input.Keys.LEFT)left=true;
            if(key==Input.Keys.D||key==Input.Keys.RIGHT)right=true;
            if(key==Input.Keys.SPACE||key==Input.Keys.W||key==Input.Keys.UP)jumpHeld=true;
            if(key==Input.Keys.SHIFT_LEFT||key==Input.Keys.SHIFT_RIGHT)dash();
            if(key==Input.Keys.E||key==Input.Keys.F)openShop();
            if(upgradeOpen&&key>=Input.Keys.NUM_1&&key<=Input.Keys.NUM_3)chooseUpgrade(key-Input.Keys.NUM_1);
            if(shopOpen&&key>=Input.Keys.NUM_1&&key<=Input.Keys.NUM_3)chooseShop(key-Input.Keys.NUM_1);
            if(gameOver){resetGame();}
            return true;
        }
        @Override public boolean keyUp(int key) {
            if(key==Input.Keys.A||key==Input.Keys.LEFT)left=false;
            if(key==Input.Keys.D||key==Input.Keys.RIGHT)right=false;
            if(key==Input.Keys.SPACE||key==Input.Keys.W||key==Input.Keys.UP)jumpHeld=false;
            return true;
        }
        @Override public boolean touchDown(int x,int y,int pointer,int button) {
            float ux=x,uy=uiH-y;
            if(gameOver){resetGame();return true;}
            if(upgradeOpen){int choice=modalChoice(ux,uy);if(choice>=0)chooseUpgrade(choice);return true;}
            if(shopOpen){int choice=modalChoice(ux,uy);if(choice>=0)chooseShop(choice);return true;}
            if(ux<uiW*.34f && uy<stickY+stickR*1.5f){
                joystickPointer=pointer;joystickCenterX=ux;joystickCenterY=uy;updateJoystick(ux);return true;
            }
            if(hit(ux,uy,jumpX,jumpY,buttonR*1.3f)){jumpHeld=true;return true;}
            if(hit(ux,uy,dashX,dashY,buttonR*1.3f)){dash();return true;}
            if(hit(ux,uy,fireX,fireY,buttonR*1.3f)){fireHeld=true;return true;}
            if(hit(ux,uy,shopX,shopY,buttonR*1.3f)){openShop();return true;}
            if(ux>uiW-230&&uy>uiH-125&&uy<uiH-10){return true;}
            return false;
        }
        @Override public boolean touchDragged(int x,int y,int pointer) {
            if(pointer==joystickPointer){updateJoystick(x);return true;}
            return false;
        }
        @Override public boolean touchUp(int x,int y,int pointer,int button) {
            if(pointer==joystickPointer){joystickPointer=-1;joystickX=0;}
            if(hit(x,uiH-y,jumpX,jumpY,buttonR*1.3f))jumpHeld=false;
            if(hit(x,uiH-y,fireX,fireY,buttonR*1.3f))fireHeld=false;
            return true;
        }
        private int modalChoice(float x,float y){
            float w=uiW*.19f,g=uiW*.025f,total=w*3+g*2,start=(uiW-total)/2f;
            if(y<uiH*.23f||y>uiH*.55f)return -1;
            for(int i=0;i<3;i++){float cx=start+i*(w+g);if(x>=cx&&x<=cx+w)return i;}
            return -1;
        }
        private void updateJoystick(float x){
            joystickX=MathUtils.clamp((x-joystickCenterX)/(stickR*1.35f),-1,1);
            if(Math.abs(joystickX)>.12f){player.face=joystickX>0?1:-1;}
        }
        private boolean hit(float x,float y,float bx,float by,float r){return Vector2.dst(x,y,bx,by)<=r;}
    }

    private void dash(){
        if(player.dashCooldown>0||upgradeOpen||shopOpen||gameOver)return;
        player.dashTime=.22f;player.dashCooldown=Math.max(.55f,1.5f-player.jet*.2f);
        player.vy=Math.max(player.vy,100f);player.invuln=.30f;
        for(int i=0;i<16;i++)particles.add(new Particle(player.x,player.y+45,
                -player.face*(50+random.nextFloat()*250),random.nextFloat()*130-50,.28f,
                new Color(.50f,.9f,.85f,1),2+random.nextFloat()*4));
    }

    private void resetGame(){
        enemies.clear();projectiles.clear();particles.clear();coinsPickupVisual.clear();
        player.reset();day=1;dayClock=30;night=false;coins=0;kills=0;level=1;xp=0;xpNeed=30;spawned=0;nightQuota=0;bossSpawnedDay=-1;
        player.x=180;player.y=FLOOR;cameraX=0;gameOver=false;upgradeOpen=false;shopOpen=false;showToast("TITAN UNIT ONLINE");
    }

    @Override public void pause() { super.pause(); }
    @Override public void resume() { super.resume(); }
    @Override public void dispose() {
        batch.dispose();shapes.dispose();font.dispose();
        forestDay.dispose();forestToxic.dispose();forestZone.dispose();groundTexture.dispose();
        mechSheet.dispose();walkerTex.dispose();jumperTex.dispose();flyerTex.dispose();spitterTex.dispose();bossTex.dispose();
    }

    private static class Player {
        float x,y,vx,vy,w=58,h=104,hp=180,maxHp=180,speed=255,fireRate=.32f,fireTimer=0,damage=22,crit=.08f;
        float invuln=0,dashTime=0,dashCooldown=0,muzzleTime=0,recoil=0,hurtFlash=0,animTime=0,stepTimer=0;
        float missileCooldown=2,droneCooldown=.8f,empTimer=10,repairTimer=0;
        int face=1,weapon=0,drone=0,missiles=0,shield=0,repair=0,jet=1;
        boolean grounded=true;
        void reset(){hp=maxHp=180;vx=vy=0;speed=255;fireRate=.32f;damage=22;crit=.08f;weapon=0;drone=missiles=shield=repair=0;jet=1;invuln=dashTime=dashCooldown=muzzleTime=recoil=hurtFlash=animTime=0;grounded=true;}
    }
    private static class Enemy {
        static final int WALKER=0,JUMPER=1,FLYER=2,SPITTER=3,BOSS=4;
        int kind;float x,y,hp,maxHp,speed,damage,w=54,h=78,vy,clock,attackTimer=.8f,contactTimer=.4f,jumpTimer=.6f,stun;
        boolean mainBoss;
        Enemy(int kind,float x,float y,float hp,float speed,float damage){this.kind=kind;this.x=x;this.y=y;this.hp=this.maxHp=hp;this.speed=speed;this.damage=damage;this.w=kind==BOSS?105:kind==WALKER?55:kind==JUMPER?62:52;this.h=kind==BOSS?112:kind==FLYER?64:76;}
    }
    private static class Projectile {
        float x,y,vx,vy,damage,life=2.0f;boolean enemy,drone,critical,rocket;
        Projectile(float x,float y,float vx,float vy,float damage,boolean enemy,boolean drone,boolean critical){this(x,y,vx,vy,damage,enemy,drone,critical,false);}
        Projectile(float x,float y,float vx,float vy,float damage,boolean enemy,boolean drone,boolean critical,boolean rocket){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.damage=damage;this.enemy=enemy;this.drone=drone;this.critical=critical;this.rocket=rocket;}
    }
    private static class Particle {
        float x,y,vx,vy,life,maxLife,size;Color color;
        Particle(float x,float y,float vx,float vy,float life,Color color,float size){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.life=this.maxLife=life;this.color=new Color(color);this.size=size;}
    }
    private static class Coin {float x,y,life=12;Coin(float x,float y){this.x=x;this.y=y;}}
    private static class Platform {float x,y,w,h;Platform(float x,float y,float w,float h){this.x=x;this.y=y;this.w=w;this.h=h;}}
}
